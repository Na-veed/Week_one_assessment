package stock;

import material.Accessories;

public class Main {

	

	public static void main(String[] args) {

		Accessories accessories[] = new Accessories[10];
		
		for (int i = 0; i < accessories.length; i++) {
			accessories[i] = new Accessories();
		}
		
		System.out.println(accessories[8].quantity);

	}

}
