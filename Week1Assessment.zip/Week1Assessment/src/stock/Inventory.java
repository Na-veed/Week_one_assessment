package stock;

public abstract class Inventory {
	
	public int quantity;
	
	public int lowOrderLevelQuantity ;

}
