package worker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Client {
	
	public static void main(String[] args) {
		List<DailyWorker> list = new ArrayList<DailyWorker>();
		list.add(new DailyWorker(7, "naveed","dailywage" ));
		list.add(new DailyWorker(4, "imran", "dailywage"));
		list.add(new DailyWorker(8, "arun","dailywage"));
		list.add(new DailyWorker(2, "shabbir","dailywage"));
		list.add(new DailyWorker(9, "madhu","dailywage"));
		list.add(new DailyWorker(10, "rahul","dailywage"));
		list.add(new DailyWorker(5 ,"javed","dailywage"));
		
		
		
		
		Collections.sort(list, new Comparator<DailyWorker>() {

			@Override
			public int compare(DailyWorker o1, DailyWorker o2) {
				// TODO Auto-generated method stub
				if(o1.getWorkedDays() > o2.getWorkedDays()) {
					return -1;
				}
				return 1;
			}
			
		});
		
		System.out.println("List of daily workers from highest number of days work to lowest number of days");
		System.out.println();
		
		
		
		for (DailyWorker dailyWorker : list) {
			System.out.println(dailyWorker);
		}
		
		List<SalariedWorker> list2 = new ArrayList<SalariedWorker>();
		list2.add(new SalariedWorker("ramya"));
		list2.add(new SalariedWorker("Banu"));
		list2.add(new SalariedWorker("vijay"));
		list2.add(new SalariedWorker("mega"));
		list2.add(new SalariedWorker("reyyy"));
		list2.add(new SalariedWorker("madhu"));
		list2.add(new SalariedWorker("vee"));
		
		System.out.println();
		System.out.println("List of salaried workers");
		System.out.println();
		
		for (SalariedWorker salariedWorker : list2) {
			System.out.println(salariedWorker);
		}
		
	}

}
