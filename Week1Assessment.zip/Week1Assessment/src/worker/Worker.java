package worker;

public abstract class Worker{
	
	public int salary;
	
	public int name;
	
	
	public abstract int pay(int salary,int worked);
	
	
	
}
