package worker;

public class SalariedWorker extends Worker {

	public int totalSalary;

	public String name;

	public int salary;

	public int salaryPerWeek = 6000;

	public SalariedWorker() {
		// TODO Auto-generated constructor stub
	}

	public SalariedWorker(String name) {
		super();

		this.name = name;

	}

	@Override
	public int pay(int salary,int salaryPerWeek) {
		// TODO Auto-generated method stub
		totalSalary = salary+salaryPerWeek;
		return totalSalary;
	}

	@Override
	public String toString() {
		return "SalariedWorker [totalSalary=" + totalSalary + ", name=" + name + ", salary=" + salary
				+ ", salaryPerWeek=" + salaryPerWeek + "]";
	}

}
