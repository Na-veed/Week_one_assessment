package worker;

public class DailyWorker extends Worker {

	public int workedDays;

	public final int salary = 1000;
	
	public String workingType;

	public String name;
	
	public int totalSalary;

	public int getWorkedDays() {
		return workedDays;
	}

	public int getSalary() {
		return salary;
	}

	public String getName() {
		return name;
	}

	public DailyWorker() {
		// TODO Auto-generated constructor stub
	}

	public DailyWorker(int workedDays, String name, String workingType) {
		super();
		this.workedDays = workedDays;
		this.workingType = workingType;
		this.name = name;

	}



	@Override
	public String toString() {
		return "DailyWorker [workedDays=" + workedDays + ", salary=" + salary + ", workingType=" + workingType
				+ ", name=" + name + ", totalSalary=" + totalSalary + "]";
	}

	@Override
	public int pay(int salary, int worked) {
		// TODO Auto-generated method stub
		totalSalary = salary + workedDays;
		return totalSalary;
	}


	
	



}
