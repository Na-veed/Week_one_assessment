package material;

import stock.Inventory;

public class Laptops extends Inventory {
	
	public Laptops() {
		quantity = quantity++;
	}

	 public int quantity= 0;
	 
	 public int lowOrderLevelQuantity = 3;
	 
	 public int laptopId;

	public Laptops(int laptopId,int quantity, int lowOrderLevelQuantity) {
		super();
		this.quantity = quantity;
		this.lowOrderLevelQuantity = lowOrderLevelQuantity;
	}
	 
	 
	
}
