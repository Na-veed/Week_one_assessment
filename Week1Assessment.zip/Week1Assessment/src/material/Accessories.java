package material;


import stock.Inventory;

public class Accessories extends Inventory{
	
	public Accessories() {
		// TODO Auto-generated constructor stub
	}
	
	private int uniqueId;
	
	
}

