package tax;

import java.util.Scanner;

public class GeneralTax {

	int annualIncome;

	String gender;

	double tax = 0;

	Scanner sc = new Scanner(System.in);

	// this method is used for getting inputs
	public void input() {
		System.out.println("Please enter your annual income:");
		try {
			annualIncome = sc.nextInt();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Please select your gender:");
		System.out.println("1.male");
		System.out.println("2.female");
		try {
			gender = sc.next();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// calculate method is getting called
		taxCalculate();
	}

	public void taxCalculate() {

		// if user is male it will execute this method

		if (gender.equals("male")) {

			if ((annualIncome >= 0) && (annualIncome <= 180000)) {

				tax = 0;

			} else if ((annualIncome >= 180001) && (annualIncome <= 500000)) {

				tax = annualIncome * 0.10;

			} else if ((annualIncome >= 500001) && (annualIncome <= 800000)) {

				tax = 0.20 * annualIncome;

			} else {
				tax = 0.30 * annualIncome;
			}

			System.out.println("Your annual tax is " + tax);
		}

		// if user is female this method will be executed
		else if (gender.equals("female")) {

			System.out.println("Please enter the year to pay the tax for:");
			int year = sc.nextInt();

			// if the female user is paying tax for 2012 - 2013 this will get into this
			// method
			if ((year == 2012) || (year == 2013)) {

				if ((annualIncome >= 0) && (annualIncome <= 190000)) {
					tax = 0;
				} else if ((annualIncome >= 190001) && (annualIncome <= 500000)) {
					tax = annualIncome * 0.10;
				} else if ((annualIncome >= 500001) && (annualIncome <= 800000)) {
					tax = annualIncome * 0.20;

				} else {
					tax = annualIncome * 0.30;
				}

				System.out.println("Your annual tax is " + tax);
			}

			else {
				if ((annualIncome >= 0) && (annualIncome <= 180000)) {

					tax = 0;

				} else if ((annualIncome >= 180001) && (annualIncome <= 500000)) {

					tax = annualIncome * 0.10;

				} else if ((annualIncome >= 500001) && (annualIncome <= 800000)) {

					tax = 0.20 * annualIncome;

				} else {
					tax = 0.30 * annualIncome;
				}

				System.out.println("Your annual tax is " + tax);
			}
		}

	}



	public static void main(String[] args) {

		GeneralTax gt = new GeneralTax();
		// input method is gettting called
		gt.input();

	}

}
