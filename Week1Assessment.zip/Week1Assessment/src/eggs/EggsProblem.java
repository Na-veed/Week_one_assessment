package eggs;

import java.util.Scanner;

public class EggsProblem {
	
	int N ;
	
	Scanner sc = new Scanner(System.in);
	
	public void input() {
		System.out.println("Enter the total number of eggs");
		N = sc.nextInt();
	}
	
	public void calculateQuotient() {
		int gross = N/144;
		System.out.println("Total number of gross is " + gross);
	}
	
	public void calculateRemainder() {
		int dozen = N%144;
		int temp = dozen/12;
		System.out.println("Total number of dozen is " + temp);
		int eggs = dozen%12;
		System.out.println("Total number of eggs is " + eggs);
	}
	
	public static void main(String[] args) {
		EggsProblem egg = new EggsProblem();
		egg.input();
		egg.calculateQuotient();
		egg.calculateRemainder();
	}
	
	

}
